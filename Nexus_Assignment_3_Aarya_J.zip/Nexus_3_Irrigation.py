import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix,roc_auc_score,recall_score,f1_score,precision_score,matthews_corrcoef,balanced_accuracy_score
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import GradientBoostingClassifier
#Loading the Dataset:
df=pd.read_csv("Irrigation_Classification.csv")
print(df.shape)
print(df.head(10))
print(df.isnull().sum())
print(df.dtypes)
print(df.columns)
print(df.info)
print(df.nunique())
print(df['CropType'].unique())

#Converting object type to numerical type:
mapping={'Wheat':1,'Groundnuts':2,'Garden Flowers':3,'Maize':4,'Paddy':5,'Potato':6,'Pulse':7,'Sugarcane':8,'Coffee':9}
df['CropType']=df['CropType'].map(mapping)

print(df.describe())
print(df.head(10))

#Exploratory Data Analysis:

# Univariate EDA:
# Determing the outliers:
sns.boxplot(x=df['CropDays'])
plt.show()

sns.boxplot(x=df['SoilMoisture'])
plt.show()

sns.boxplot(x=df['temperature'])
plt.show()

sns.boxplot(x=df['Humidity'])
plt.show()
# EDA Bivariate:

from sklearn.preprocessing import StandardScaler

selected_columns = ['CropDays', 'SoilMoisture', 'temperature', 'Humidity']
scaler = StandardScaler()
standardized_data = scaler.fit_transform(df[selected_columns])

# Exploratory Data Analysis Bivariate:
# Type of Crop Vs Number of Growth Days
plt.bar(df['CropType'],df['CropDays'],color = 'blue')
plt.show()

# Exploratory Data Analysis for each of the crops:
crops = df['CropType'].unique()
for crop in crops:
    crop_data = df[df['CropType']==crop]

    #Correlation matrix:
    corr_matrix=crop_data.corr()
    sns.heatmap(corr_matrix,annot=True,cmap='Spectral')
    plt.title(f'Correlation Matrix -{crop}')
    plt.show()

    #Some important parameters comparison:
    plt.bar(crop_data['CropDays'],crop_data['SoilMoisture'],color='blue')
    plt.show()

crop_1=df[df['CropType']=='Groundnut']
plt.plot(df['SoilMoisture'],df['CropDays'])
plt.show()



# Application Of Analytical Methods:


#Defining the dataset into input and output:
x = df.drop('Irrigation',axis=1)
y = df['Irrigation']

print(y.shape)
#Train test split :
x_train,x_test,y_train,y_test = train_test_split(x,y,test_size=0.2, random_state=42)

#Logistic Regression model:
model_1 = LogisticRegression()
model_1.fit(x_train,y_train)

y_pred_LR = model_1.predict(x_test)

# Evaluation:
accuracy_LR = accuracy_score(y_test, y_pred_LR)
auc_LR = roc_auc_score(y_test,model_1.predict_proba(x_test)[:,1])
recall_LR = recall_score(y_test,y_pred_LR)
f1_LR = f1_score(y_test,y_pred_LR)
gmean_LR = balanced_accuracy_score(y_test,y_pred_LR)
precision_LR = precision_score(y_test,y_pred_LR)

print(f"Accuracy: {accuracy_LR}")
print(f"\n AUC : {auc_LR}")
print(f"Recall : {recall_LR}")
print(f"F1-score:{f1_LR}")
print(f"gmean : {gmean_LR}")
print(f"Precision : {precision_LR}")

# Naive Bayes model :
model_2 = GaussianNB()
model_2.fit(x_train,y_train)

y_pred_NB = model_2.predict(x_test)

accuracy_NB = accuracy_score(y_test,y_pred_NB)
auc_NB = roc_auc_score(y_test,model_2.predict_proba(x_test)[:,1])
recall_NB = recall_score(y_test,y_pred_NB)
f1_NB = f1_score(y_test,y_pred_NB)
gmean_NB = balanced_accuracy_score(y_test,y_pred_NB)
precision_NB = precision_score(y_test,y_pred_NB)

print("\n========= Naive Bayes Model==========")
print(f"Accuracy : {accuracy_NB}")
print(f"AUC:{auc_NB}")
print(f"Recall : {recall_NB}")
print(f"F1-score : {f1_NB}")
print(f"gmean : {gmean_NB}")
print(f"Precision : {precision_NB}")

# Support Vector Machines Classifier :
model_3 = SVC(probability=True, random_state=42)
model_3.fit(x_train,y_train)

y_pred_SV = model_3.predict(x_test)

accuracy_SV = accuracy_score(y_test,y_pred_SV)
auc_SV = roc_auc_score(y_test,model_3.predict_proba(x_test)[:,1])
recall_SV = recall_score(y_test,y_pred_SV)
f1_SV = f1_score(y_test,y_pred_SV)
gmean_SV = balanced_accuracy_score(y_test,y_pred_SV)
precision_SV = precision_score(y_test,y_pred_SV)

print("\n========= Support Vector Machines Classifier Model ==========")
print(f"Accuracy : {accuracy_SV}")
print(f"AUC:{auc_SV}")
print(f"Recall : {recall_SV}")
print(f"F1-score : {f1_SV}")
print(f"gmean : {gmean_SV}")
print(f"Precision : {precision_SV}")

# Decision Tree Classifier Model:
model_4 = DecisionTreeClassifier(random_state=42)
model_4.fit(x_train,y_train)

y_pred_DT = model_4.predict(x_test)

accuracy_DT = accuracy_score(y_test,y_pred_DT)
auc_DT = roc_auc_score(y_test,model_4.predict_proba(x_test)[:,1])
recall_DT = recall_score(y_test,y_pred_DT)
f1_DT = f1_score(y_test,y_pred_DT)
gmean_DT = balanced_accuracy_score(y_test,y_pred_DT)
precision_DT = precision_score(y_test,y_pred_DT)

print("\n========= Decision Trees Model==========")
print(f"Accuracy : {accuracy_DT}")
print(f"AUC:{auc_DT}")
print(f"Recall : {recall_DT}")
print(f"F1-score : {f1_DT}")
print(f"gmean : {gmean_DT}")
print(f"Precision : {precision_DT}")
# Random Forest Classifier:
model_5= RandomForestClassifier(n_estimators=100,random_state=42)
model_5.fit(x_train,y_train)
y_pred_RF=model_5.predict(x_test)

accuracy_RF = accuracy_score(y_test,y_pred_RF)
auc_RF = roc_auc_score(y_test,model_5.predict_proba(x_test)[:,1])
recall_RF = recall_score(y_test,y_pred_RF)
f1_RF = f1_score(y_test,y_pred_RF)
gmean_RF = balanced_accuracy_score(y_test,y_pred_RF)
precision_RF = precision_score(y_test,y_pred_RF)

print("\n========= Random Forest Classifier ==========")
print(f"Accuracy : {accuracy_RF}")
print(f"AUC:{auc_RF}")
print(f"Recall : {recall_RF}")
print(f"F1-score : {f1_RF}")
print(f"gmean : {gmean_RF}")
print(f"Precision : {precision_RF}")

# K Nearest Neighbours Model:
k_value = 5
model_6= KNeighborsClassifier(n_neighbors = k_value)
model_6.fit(x_train,y_train)
y_pred_KN=model_6.predict(x_test)

accuracy_KN = accuracy_score(y_test,y_pred_KN)
auc_KN = roc_auc_score(y_test,model_6.predict_proba(x_test)[:,1])
recall_KN = recall_score(y_test,y_pred_KN)
f1_KN = f1_score(y_test,y_pred_KN)
gmean_KN = balanced_accuracy_score(y_test,y_pred_KN)
precision_KN = precision_score(y_test,y_pred_KN)

print("\n========= K Nearest Neighbours ==========")
print(f"Accuracy : {accuracy_KN}")
print(f"AUC:{auc_KN}")
print(f"Recall : {recall_KN}")
print(f"F1-score : {f1_KN}")
print(f"gmean : {gmean_KN}")
print(f"Precision : {precision_KN}")

#Gradient Boosting Classifier Algorithm :
model_7= GradientBoostingClassifier(random_state=42)
model_7.fit(x_train,y_train)
y_pred_GB=model_7.predict(x_test)

accuracy_GB = accuracy_score(y_test,y_pred_GB)
auc_GB = roc_auc_score(y_test,model_7.predict_proba(x_test)[:,1])
recall_GB = recall_score(y_test,y_pred_GB)
f1_GB = f1_score(y_test,y_pred_GB)
gmean_GB = balanced_accuracy_score(y_test,y_pred_GB)
precision_GB = precision_score(y_test,y_pred_GB)

print("\n========= Gradient Boosting Classifier ==========")
print(f"Accuracy : {accuracy_GB}")
print(f"AUC:{auc_GB}")
print(f"Recall : {recall_GB}")
print(f"F1-score : {f1_GB}")
print(f"gmean : {gmean_GB}")
print(f"Precision : {precision_GB}")